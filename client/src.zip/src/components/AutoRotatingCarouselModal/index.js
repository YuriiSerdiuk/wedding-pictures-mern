export { default } from "./AutoRotatingCarouselModal";
