export { default } from "./Gallery.conteiner";
