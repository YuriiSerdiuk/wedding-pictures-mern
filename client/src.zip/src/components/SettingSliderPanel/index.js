import {SettingSliderPanel} from './SettingSliderPanel';

export default  SettingSliderPanel;
