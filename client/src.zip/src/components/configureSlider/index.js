export { default } from "./ConfigereSlider";
