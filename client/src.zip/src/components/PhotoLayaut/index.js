export { default } from "./PhotoLayaut";
