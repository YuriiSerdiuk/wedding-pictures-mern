export { default } from "./AwesomeSlider.container";
