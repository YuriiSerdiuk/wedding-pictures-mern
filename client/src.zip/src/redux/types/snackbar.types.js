export const MESSAGE = "MESSAGE";
export const ERROR = "ERROR";
