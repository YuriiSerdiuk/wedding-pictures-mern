export const REQUEST_SIGN_UP = "REQUEST_SIGN_UP";
export const UPDATE_SIGN_UP = "UPDATE_SIGN_UP";
export const FAILURE_SIGN_UP = "FAILURE_SIGN_UP";

export const REQUEST_SIGN_IN = "REQUEST_SIGN_IN";
export const UPDATE_SIGN_IN = "UPDATE_SIGN_IN";
export const FAILURE_SIGN_IN = "FAILURE_SIGN_IN";

export const LOG_OUT = "LOG_OUT";
