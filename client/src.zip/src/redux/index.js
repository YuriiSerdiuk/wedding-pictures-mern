export { default } from "./store";
