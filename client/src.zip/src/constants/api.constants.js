export const URL = "http://localhost:9988";
export const DEV_URL = "http://localhost:9988";

export const URL_PATHS = {
  SignUp: "/auth/register",
  SignIn: "/auth/login",
  Upload: "/upload/photo",
  UploadAudio: "/upload/audio",
  GetImages: "/upload/photos",
  deleteImage: "/upload/delete",
  slider: "/slider",
  Test: "/auth/"
};
